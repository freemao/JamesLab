unsigned char post2g(double pAB, double pBB);
int g2post(unsigned char code, double *pAA, double *pAB, double *pBB);
unsigned char mean2g(double mean, int maxE);
double g2mean(unsigned char code);
int g2ad(unsigned char code, double *xadd, double *xdom);


